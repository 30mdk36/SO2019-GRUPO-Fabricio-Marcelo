#include "parallelMonteCarlo.h"

void parallelMonteCarlo(){


	pthread_t thread[NTHREADS];

	mpf_t result;

	int ret[NTHREADS], i;

	monteCarloStruct *mCS[NTHREADS];

	mpf_set_default_prec(131071);
	/*Allocates structures to be passed on threads and sets their size of iteractions*/
	mpf_init(result);
	for(i = 0; i < NTHREADS; i++)
	{	
		mCS[i] = (monteCarloStruct *)calloc(1, sizeof(monteCarloStruct));
		mCS[i]->size = MAXIT/NTHREADS;
		ret[i] = pthread_create(&thread[i], NULL, itself, (void*) mCS[i]);

		if(ret[i]){
			fprintf(stderr,"Error - pthread_create() return code: %d\n",ret[i]);
			exit(EXIT_FAILURE);
		}
	}

	/*Wait for all threads to finish*/
	for(i = 0; i < NTHREADS; i++)
	{
		pthread_join(thread[i], NULL);
	}

	/*Sums the results and free the structures*/
	for(i = 0; i < NTHREADS; i++)
	{
		mpf_add(result, result, mCS[i]->result);
		free(mCS[i]);
	}
	
	/*Gives the result by the mean of the sum of the result of each thread*/
	mpf_div_ui(result, result, NTHREADS);
	gmp_printf( "Pi pelo método de Montecarlo paralelo: %.6Ff\n", result );
	mpf_clear(result);
	pthread_exit(NULL);

}

void *itself(void *ptr){
	monteCarloStruct *mCS = (monteCarloStruct*) ptr;

	long unsigned int i, count;
	double calc;

	struct BoxMullerState state;

	/*state.w=0;
	state.useLast=0;
	state.x1=0;
	state.x2=0;
	state.y1=0;
	state.y2=0;
	state.random=0;*/
	initBoxMullerState(&state);
	calc=0;
	count=0;
	/*Calculates PI using the Monte Carlo method*/
	for ( i=0; i<mCS->size; i++) {

    	if (!boxMullerRandom(&state))
    		count++;

    	printf("Cont intra-thread = %d\n", i);
    }
   	
   	calc= count/mCS->size;
	mpf_set_d(mCS->result, calc);
   	mpf_mul_ui(mCS->result, mCS->result,4);

   	return NULL;
}
