#include "gaussLegendre.h"

void gl()
{
    long unsigned int i;
	mpf_t a, an, b, t, pi, temp1, temp2, p;

    /*A precisao padrao sera no minimo 10.000.000*log10 na base 2.=  33.219.280 */
	mpf_set_default_prec(1048575);

    /*O objeto mpf_t deve ser inicializado antes de receber algum valor.*/
    mpf_init(a), mpf_init(b),mpf_init(t), mpf_init(pi),mpf_init(an), mpf_init(temp1), mpf_init(temp2), mpf_init(p);

    /*Inicializando as variaveis*/
    mpf_set_d (a,1.0);

    /*bAnt = 1/sqrt(2)*/
    mpf_set_d (temp1,2.0);        /* temp1 = 2*/
    mpf_sqrt (temp2,temp1);     /* temp2 = sqrt(temp1) */
    mpf_ui_div (b,1, temp2); /* b = 1/temp2 */

    mpf_set_d (t,0.25);
    mpf_set_d (p,1);

    /*Calculates Pi using Gauss-Legendre algorithm*/
	for( i = 0 ; i <= MAXIT ; i++ )
    {
        mpf_set (an,a);
        /*calculo do valor An+1
        a = (an + b)/2 */
        mpf_add (temp1,an,b);	/*temp1 = an + b   */
        mpf_div_ui(a,temp1,2.0);	/*a = (temp1)/2     */

        /*calculo do valor Bn+1
        b = sqrt(an * b) */
        mpf_mul(temp1,an,b); /*temp1 = an * b   */
        mpf_sqrt(b,temp1); /*b = sqrt(temp1)    */

        /*calculo do valor Tn+1
        t = t - p*pow((an-a),2) */
        mpf_sub(temp1,an,a); 	/*temp 1 = an-a*/
        mpf_pow_ui(temp2, temp1, 2.0);	/*temp2 = temp1^2*/
        mpf_mul(temp1,p,temp2);		/*temp1= p*temp2 */
        mpf_sub(t,t,temp1); 	/*t = t - temp1 */

        /*calculo do valor Pn+1
        p= 2*p */
        mpf_mul_ui(p,p,2.0);    /*p = 2*p */
    }

    mpf_add(temp1,a,b);       /*temp1 = a + b   */
    mpf_pow_ui (temp1,temp1,2);     /*temp1 = temp1^2*/
    mpf_mul_ui(temp2,t,4);       /*temp2 = 4*t */
    mpf_div (pi,temp1,temp2);    /*pi = (temp1)/(temp2) */
    
    gmp_printf( "Pi pelo método de Gauss-Legendre sequencial: %.6Ff\n", pi );

    mpf_clear(an),mpf_clear(a),mpf_clear(b),mpf_clear(temp1),mpf_clear(temp2),mpf_clear(t),mpf_clear(p),mpf_clear(pi); /*Limpa as variáveis da memória*/

}
