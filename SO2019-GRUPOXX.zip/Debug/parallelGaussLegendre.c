#include "parallelGaussLegendre.h"

typedef struct
{
    mpf_t a, b, t, p, an;

}dataGL;

void calculaA ( void * param );
void calculaB ( void * param );
void calculaT ( void * param );
void calculaP ( void * param );

void parallelGaussLegendre(void)
{
    mpf_t pi, temp1, temp2;
	pthread_t tA, tB, tT, tP;
	long unsigned int iteracoes = 0;
	dataGL dadosGaussL;

    mpf_set_default_prec (1048575);

    /*O objeto mpf_t deve ser inicializado antes de receber algum valor.*/
    mpf_init(dadosGaussL.a), mpf_init(dadosGaussL.b),mpf_init(dadosGaussL.t), mpf_init(dadosGaussL.p), mpf_init(temp1),mpf_init(temp2),mpf_init(dadosGaussL.an),mpf_init(pi);

    /*Inicializando as variaveis*/
    mpf_set_d (dadosGaussL.a,1);

    /*bAnt = 1/sqrt(2)*/
    mpf_set_d (temp1,2);        /* temp1 = 2*/
    mpf_sqrt (temp2,temp1);     /* temp2 = sqrt(temp1) */
    mpf_ui_div (dadosGaussL.b,1, temp2); /* b = 1/temp2 */

    mpf_set_d (dadosGaussL.t,0.25);
    mpf_set_d (dadosGaussL.p,1);

   	while(iteracoes < MAXIT)
    {

		mpf_set(dadosGaussL.an,dadosGaussL.a);
   		pthread_create (&tA, NULL, (void *) &calculaA, (void *) &dadosGaussL);
    	pthread_create (&tB, NULL, (void *) &calculaB, (void *) &dadosGaussL);
		pthread_create (&tT, NULL, (void *) &calculaT, (void *) &dadosGaussL);
		pthread_create (&tP, NULL, (void *) &calculaP, (void *) &dadosGaussL);

		/* Espera as threads terminarem para prosseguir com os calculos */
		pthread_join(tA, NULL);
    	pthread_join(tB, NULL);
		pthread_join(tT, NULL);
		pthread_join(tP, NULL);

		++iteracoes;

    }

	/*calculo do valor de pi
    pi = (pow((aPos+bPos),2))/(4*tPos) */

	mpf_add(temp1,dadosGaussL.a,dadosGaussL.b);       /*temp1 = a + b   */
	mpf_pow_ui (temp1,temp1,2);     /*temp1 = temp1^2*/
	mpf_mul_ui(temp2,dadosGaussL.t,4);       /*temp2 = 4*t */
	mpf_div (pi,temp1,temp2);    /*pi = (temp1)/(temp2) */

	gmp_printf( "Pi pelo método de Gauss-Legendre paralelo: %.6Ff\n", pi );

	mpf_clear(dadosGaussL.a),mpf_clear(dadosGaussL.b),mpf_clear(dadosGaussL.t),mpf_clear(dadosGaussL.p),mpf_clear(dadosGaussL.an),mpf_clear(pi), mpf_clear(temp1),mpf_clear(temp2);


}


void calculaA ( void * param )
{

	dataGL *dado;
	mpf_t temp1;
	mpf_init(temp1);

    dado = (dataGL *) param;
    /*calculo do valor An+1
    a = (an + b)/2 */
    mpf_add(temp1,dado->an,dado->b);   /*temp1 = an + b   */
    mpf_div_ui (dado->a,temp1,2); /*a = (temp1)/2     */
	mpf_clear(temp1);

    pthread_exit(0); /* exit */
}

void calculaB ( void * param )
{

	dataGL *dado;
	mpf_t temp1;
	mpf_init(temp1);

    dado = (dataGL *) param;

	/*calculo do valor Bn+1
    bPos = sqrt(an * b) */
	mpf_mul (temp1,dado->an,dado->b);  /*temp1 = an * b   */
    mpf_sqrt (dado->b,temp1);      		/*b = sqrt(temp1)    */
	mpf_clear(temp1);

    pthread_exit(0); /* exit */
}

void calculaT ( void * param )
{

	dataGL *dado;
	mpf_t temp1;
	mpf_init(temp1);

    dado = (dataGL *) param;

	/*calculo do valor Tn+1
    t = t - p*pow((an-a),2)

	Obs.: Para depender apenas dos valores anteriores, que ja estao calculados,
	substituimos a = (an + b)/2. Portanto,

	t = t - p*pow(((an-b)/2),2)
	*/
	mpf_sub (temp1, dado->an, dado->b);    /*temp 1 = an-b*/
	mpf_div_ui (temp1,temp1,2); 	/*temp1 = (temp1)/2     */
    mpf_pow_ui (temp1,temp1,2);     /*temp1 = temp1^2*/
    mpf_mul (temp1,dado->p,temp1);     /*temp1= p*temp1 */
    mpf_sub (dado->t, dado-> t, temp1);    /*t = t - temp1 */
	
	mpf_clear(temp1);

    pthread_exit(0); /* exit */
}

void calculaP ( void * param )
{
	dataGL *dado;
    dado = (dataGL *) param;

	/*calculo do valor Pn+1
    p = 2*p */
    mpf_mul_ui(dado->p,dado->p,2);    /*p = 2*p */

    pthread_exit(0); /* exit */

}
