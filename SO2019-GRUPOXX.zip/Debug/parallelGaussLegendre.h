#ifndef _PARALLELGAUSSLEGENDRE_H_
#define _PARALLELGAUSSLEGENDRE_H_

#include <gmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include "utils.h"

void parallelGaussLegendre(void);

#endif
