ConcorrentesT1
==============

Calculating PI Using Gauss-Legendre, Borwein and Monte-Carlo formulae, and implementation of Black Scholes
