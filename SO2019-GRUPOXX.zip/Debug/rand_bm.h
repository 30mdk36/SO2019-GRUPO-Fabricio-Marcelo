#ifndef _RAND_BM_H_
#define _RAND_BM_H_

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <sys/time.h>

struct BoxMullerState
{
        double x1, x2, w, y1, y2;
        int useLast;
        unsigned int random;
};

void initBoxMullerState(struct BoxMullerState* state);

int boxMullerRandom(struct BoxMullerState* state);

double boxMullerRandom2(struct BoxMullerState* state);

unsigned int next(unsigned int x, unsigned int A, unsigned int C);

#endif
