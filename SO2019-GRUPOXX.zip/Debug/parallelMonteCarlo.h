#ifndef _PARALLELMONTECARLO_H_
#define _PARALLELMONTECARLO_H_

#include <gmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include "rand_bm.h"
#include "utils.h"

typedef struct{
	long unsigned int size;
	mpf_t result;
}monteCarloStruct;

void parallelMonteCarlo();

void *itself(void *ptr);

#endif
