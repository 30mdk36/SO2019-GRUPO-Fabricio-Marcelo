#ifndef _PARALLELBORWEIN_H_
#define _PARALLELBORWEIN_H_

#include <gmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include "utils.h"

/*tipos mpf_t para a thread*/
typedef struct{
	mpf_t a0,a1,y0,y1;
	mpf_t aux_y1,aux_y2,aux_a1,aux_a2;
	mpf_t y_valoratual; //utilizado para o calculo de a, deixando com que y nao fique dependendo da execucao de a
	long unsigned int k;
}thr_gmpf_t;


void gmp_borwein_par();
void *mpf_init_thread(mpf_t *);
void *calc_y(thr_gmpf_t *);
void *calc_a(thr_gmpf_t *);
void *mpf_seta_thread(thr_gmpf_t *);
void *mpf_sety_thread(thr_gmpf_t *);

#endif
