#ifndef _MONTECARLO_H_
#define _MONTECARLO_H_

#include <gmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "utils.h"

void montecarlo();

#endif
