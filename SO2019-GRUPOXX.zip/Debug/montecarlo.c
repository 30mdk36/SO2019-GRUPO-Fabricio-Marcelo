#include "montecarlo.h"

void montecarlo() {
	double x, y, z;
	long unsigned int i;
	mpf_t pi, intern_points, total_points, ratio;

	mpf_set_default_prec (1048575);

	srand(time(NULL));
	mpf_init(intern_points);
	mpf_init(total_points);
	mpf_init(ratio);
	mpf_init(pi);
  /*Calculates Pi using the Monte Carlo algorithm*/
	for ( i=0; i<MAXIT; i++) {
    	x = (double)rand()/RAND_MAX;
    	y = (double)rand()/RAND_MAX;
    	z = x*x+y*y;
    	if (z<=1) mpf_add_ui(intern_points, intern_points, 1);
    	mpf_add_ui(total_points, total_points, 1);
    	printf("Cont = %d\n", i);
    }

	mpf_div(ratio, intern_points, total_points);
   	mpf_mul_ui(pi, ratio, 4);
   	gmp_printf( "Pi pelo método de Montecarlo sequencial: %.6Ff\n", pi );

   	mpf_clear(pi),mpf_clear(intern_points),mpf_clear(total_points),mpf_clear(ratio); /*Limpa as variáveis da memória*/
}
