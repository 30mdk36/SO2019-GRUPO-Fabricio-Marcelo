#ifndef _GAUSSLEGENGRE_H_
#define _GAUSSLEGENGRE_H_

#include <gmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "utils.h"

void gl();

#endif
