#include "gaussLegendre.h"
#include "borwein.h"
#include "montecarlo.h"
#include "parallelMonteCarlo.h"
#include "parallelBorwein.h"
#include "parallelGaussLegendre.h"
#include "blackscholes.h"
#include "parallelBlackScholes.h"
#include "rand_bm.h"
#include <string.h>

int main(int argc, char *argv[]){

	double S, E, r, sigma, T;
	int M;
	int method = atoi(argv[1]);

	switch(method){
		case 0://Gauss-Legendre
			gl();
			break;
		case 1://Borwein
			borwein();
			break;
		case 2://Monte Carlo
			montecarlo();
			break;
		case 3://Parallel Monte Carlo
			parallelMonteCarlo();
			break;
		case 4://Parallel Borwein
			gmp_borwein_par();
			break;
		case 5://Parallel Gauss-Legendre
			parallelGaussLegendre();
			break;
		/*case 6://Black Scholes
			scanf("%lf[^.],%lf[^.],%lf[^.],%lf[^.],%lf[^.],%d", &S, &E, &r, &sigma, &T, &M);

			blackScholes(100, 110, 10, 1, 1, 100000);
			break;
		case 7://Parallel Black Scholes
			scanf("%lf", &S);
			scanf("%lf", &E);
			scanf("%lf", &r);
			scanf("%lf", &sigma);
			scanf("%lf", &T);
			scanf("%d", &M);

			parallelBlkScholes(S, E, r, sigma, T, M);
			break;*/
	}

	return 0;
}
